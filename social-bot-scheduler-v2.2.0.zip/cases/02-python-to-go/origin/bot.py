from social_bot.main import main

if __name__ == "__main__":
    main()
