from .service import BotService


def main():
    service = BotService()
    service.run()


if __name__ == "__main__":
    main()
